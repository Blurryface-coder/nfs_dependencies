This is a *modified* version of the CSI 1.0.0 spec. It's only purpose is
to test the stripping of secret fields.
