package more_ginkgo_tests

func AlwaysTrue() bool {
	return true
}
